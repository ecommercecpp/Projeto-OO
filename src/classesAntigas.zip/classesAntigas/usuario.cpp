#include "autoload.hpp"

Usuario::Usuario()
{
}
Usuario::Usuario(std::string nome, std::string cpf_cnpj, std::string endereco, std::string email, int tipo, std::string login, std::string senha) : Pessoa(nome, cpf_cnpj, endereco, email, tipo)
{
    this->login = login;
    this->senha = senha;
}
std::string Usuario::getLogin()
{
    return this->login;
}
void Usuario::setLogin(std::string login)
{
    this->login = login;
}
std::string Usuario::getSenha()
{
    return this->senha;
}
void Usuario::setSenha(std::string senha)
{
    this->senha = senha;
}
std::vector<std::string> Usuario::getPermissoes()
{
    return this->permissoes;
}
void Usuario::setPermissoes(std::vector<std::string> permissoes)
{
    this->permissoes = permissoes;
}
