#include "autoload.hpp"

Logs::Logs()
{	
}

Logs::~Logs()
{
}

Logs::Logs(Usuario usuario, ec::Date data, std::string entidade)
{
    this->usuario = usuario;
    this->data = data;
    this->entidade = entidade;
}


void Logs::setUsuario(Usuario usuario)
{
    this->usuario = usuario;
}

Usuario Logs::getUsuario()
{
    return this->usuario;
}

void Logs::setData(ec::Date data)
{
    this->data = data;
}

ec::Date Logs::getData()
{
    return this->data;
}

void Logs::setEntidade(std::string entidade)
{
    this->entidade = entidade;
}

std::string Logs::getEntidade()
{
    return this->entidade;
}
