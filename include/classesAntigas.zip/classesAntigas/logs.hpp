#ifndef _LOGS_HPP_
#define _LOGS_HPP_

#include <string>
#include <vector>

#include "date.h"
#include "exceptions.hpp"
#include "autoload.hpp"

class Logs
{
	protected:
    Usuario usuario;
		ec::Date data;
    std::string entidade;

	public:
    Logs();
    ~Logs();
    Logs(Usuario, ec::Date, std::string);

    void setUsuario(Usuario);
    Usuario getUsuario();
    void setData(ec::Date);
    ec::Date getData();
    void setEntidade(std::string);
    std::string getEntidade();

//    virtual std::string getLog() = 0;
    
};

#endif