#ifndef _SALARIO_HPP_
#define _SALARIO_HPP_

#include "autoload.hpp"

class Salario2
{
	protected:
		double valor;
		bool status;
		int motivo; // 1 - Promoção 2 - Reajuste (dissidio)
		ec::Date data;
	private:
		void setValor(double valor);
		void setMotivo(int motivo);
	public:
		Salario2();
		Salario2(double valor, bool status, int motivo);
		double getValor();
		bool getStatus();
		int getMotivo();
		ec::Date getDataAlteracao();
};

#endif