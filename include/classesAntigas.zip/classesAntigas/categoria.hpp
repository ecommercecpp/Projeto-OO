#ifndef _CATEGORIA_HPP_
#define _CATEGORIA_HPP_

#include <string>
#include "autoload.hpp"

class Categoria
{
	private:
		std::string nome;
	public:
		Categoria(std::string name);
		std::string getNome();
		void setNome(std::string name);
};

#endif