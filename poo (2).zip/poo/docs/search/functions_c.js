var searchData=
[
  ['quantidadedevendaindisponivelexception_0',['QuantidadeDeVendaIndisponivelException',['../class_quantidade_de_venda_indisponivel_exception.html#a1d8b2f5f99c3741461055ce118a5cd0c',1,'QuantidadeDeVendaIndisponivelException']]]
];
