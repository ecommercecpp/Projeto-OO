var searchData=
[
  ['year_5fto_5fseconds_0',['YEAR_TO_SECONDS',['../include_2_data_8h.html#a0db31c423606c1ec7025c2a476c797ad',1,'YEAR_TO_SECONDS():&#160;Data.h'],['../third__party_2_classe_01_data_2_data_8h.html#a0db31c423606c1ec7025c2a476c797ad',1,'YEAR_TO_SECONDS():&#160;Data.h']]]
];
