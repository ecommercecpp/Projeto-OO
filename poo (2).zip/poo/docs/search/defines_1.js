var searchData=
[
  ['hours_5fto_5fseconds_0',['HOURS_TO_SECONDS',['../include_2_data_8h.html#a394fdbdcd9223b5b01bec61e3515a5cf',1,'HOURS_TO_SECONDS():&#160;Data.h'],['../third__party_2_classe_01_data_2_data_8h.html#a394fdbdcd9223b5b01bec61e3515a5cf',1,'HOURS_TO_SECONDS():&#160;Data.h']]]
];
