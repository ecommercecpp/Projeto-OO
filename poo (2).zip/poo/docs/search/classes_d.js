var searchData=
[
  ['salario_0',['Salario',['../class_salario.html',1,'']]]
];
