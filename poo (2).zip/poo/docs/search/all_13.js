var searchData=
[
  ['userofflineexception_0',['UserOfflineException',['../class_user_offline_exception.html',1,'UserOfflineException'],['../class_user_offline_exception.html#a3002018855f0a32f26a8e284d9d3085c',1,'UserOfflineException::UserOfflineException()']]],
  ['usuario_1',['Usuario',['../class_usuario.html',1,'']]],
  ['usuario_2',['usuario',['../class_logs.html#a579d7135b9847edd8cfebdcbff6289d9',1,'Logs']]],
  ['usuario_3',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#ad0889d5f4399a6d5d97ee4bcc6be8611',1,'Usuario::Usuario(std::string nome, std::string cpf_cnpj, std::string endereco, std::string email, int tipo, std::string login, std::string senha, std::vector&lt; std::string &gt; permissoes)']]],
  ['usuario_2ecpp_4',['usuario.cpp',['../usuario_8cpp.html',1,'']]],
  ['usuario_2ehpp_5',['usuario.hpp',['../usuario_8hpp.html',1,'']]],
  ['usuariologado_6',['UsuarioLogado',['../class_usuario_logado.html',1,'UsuarioLogado'],['../class_usuario_logado.html#a45b59d05401bd3c7836a4861047af839',1,'UsuarioLogado::UsuarioLogado()']]],
  ['usuariologado_2ecpp_7',['usuarioLogado.cpp',['../usuario_logado_8cpp.html',1,'']]],
  ['usuariologado_2ehpp_8',['usuarioLogado.hpp',['../usuario_logado_8hpp.html',1,'']]]
];
