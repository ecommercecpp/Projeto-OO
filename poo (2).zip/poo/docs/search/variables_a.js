var searchData=
[
  ['permissoes_0',['permissoes',['../class_usuario.html#a3bba1c433796f3f2b516d2683831cc07',1,'Usuario']]],
  ['produto_1',['produto',['../class_venda.html#a759f8d9a2c6604859dbe396b3ca814f9',1,'Venda']]],
  ['produtos_2',['produtos',['../class_estoque.html#a6e3ed4d879630dba2b1b7a8df2486951',1,'Estoque']]]
];
