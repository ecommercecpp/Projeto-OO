var searchData=
[
  ['quantidade_0',['quantidade',['../class_venda.html#a4fa1da78a9dd560c9a0ff28d1d261a8c',1,'Venda']]]
];
