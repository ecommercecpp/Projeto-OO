var searchData=
[
  ['acessdeniedexception_0',['AcessDeniedException',['../class_acess_denied_exception.html',1,'']]]
];
