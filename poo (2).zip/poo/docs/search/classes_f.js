var searchData=
[
  ['validacpfcnpj_0',['ValidaCPFCNPJ',['../class_valida_c_p_f_c_n_p_j.html',1,'']]],
  ['veiculo_1',['Veiculo',['../class_veiculo.html',1,'']]],
  ['veiculocheioexception_2',['VeiculoCheioException',['../class_veiculo_cheio_exception.html',1,'']]],
  ['venda_3',['Venda',['../class_venda.html',1,'']]]
];
