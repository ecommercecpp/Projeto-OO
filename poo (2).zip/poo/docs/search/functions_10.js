var searchData=
[
  ['userofflineexception_0',['UserOfflineException',['../class_user_offline_exception.html#a3002018855f0a32f26a8e284d9d3085c',1,'UserOfflineException']]],
  ['usuario_1',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#ad0889d5f4399a6d5d97ee4bcc6be8611',1,'Usuario::Usuario(std::string nome, std::string cpf_cnpj, std::string endereco, std::string email, int tipo, std::string login, std::string senha, std::vector&lt; std::string &gt; permissoes)']]],
  ['usuariologado_2',['UsuarioLogado',['../class_usuario_logado.html#a45b59d05401bd3c7836a4861047af839',1,'UsuarioLogado']]]
];
