var searchData=
[
  ['tipo_0',['tipo',['../class_pessoa.html#a8fb96e6244f2f005366e751bdb8aa0a4',1,'Pessoa']]],
  ['turno_1',['turno',['../class_funcionario.html#aa618d441bfbc1cfea3766dbe5cda3e14',1,'Funcionario']]]
];
