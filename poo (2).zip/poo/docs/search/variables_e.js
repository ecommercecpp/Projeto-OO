var searchData=
[
  ['usuario_0',['usuario',['../class_logs.html#a579d7135b9847edd8cfebdcbff6289d9',1,'Logs']]]
];
