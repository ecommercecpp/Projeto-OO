var searchData=
[
  ['salario_0',['salario',['../class_funcionario.html#ace666633764be8f7be1c51beb2769627',1,'Funcionario']]],
  ['senha_1',['senha',['../class_usuario.html#a5f324af32e988e55160d5f3651b5d2b1',1,'Usuario']]],
  ['status_2',['status',['../class_funcionario.html#a3ffd40c82d198896e8c428aabb8f256b',1,'Funcionario::status()'],['../class_salario.html#a512f7812c601312a068ca15d8d7b4302',1,'Salario::status()']]]
];
