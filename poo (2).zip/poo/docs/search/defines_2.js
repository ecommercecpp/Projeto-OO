var searchData=
[
  ['minute_5fto_5fseconds_0',['MINUTE_TO_SECONDS',['../include_2_data_8h.html#a7c330b010e567e33923d8483de2d7fb2',1,'MINUTE_TO_SECONDS():&#160;Data.h'],['../third__party_2_classe_01_data_2_data_8h.html#a7c330b010e567e33923d8483de2d7fb2',1,'MINUTE_TO_SECONDS():&#160;Data.h']]]
];
