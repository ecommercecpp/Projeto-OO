var indexSectionsWithContent =
{
  0: ".abcdefghilmnopqrstuvwy~�",
  1: "abcdefilmopqrsuv",
  2: ".abcdeflmoprstuv",
  3: "abcdefgilmopqrstuvw~",
  4: "acdefhilmnpqstuv�",
  5: "dhmy",
  6: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições e Macros",
  6: "Páginas"
};

