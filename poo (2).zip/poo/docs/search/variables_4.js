var searchData=
[
  ['funcionalidade_0',['funcionalidade',['../class_log_excecao.html#ab421bcf40ad17f297d641b43564f24b3',1,'LogExcecao']]]
];
